nce_k8s_perftest
===============
0.1.4.1版本为了规避@小强的一个打点信息bug，rcEnSmartQueue和syncStart时间点有时候就会打不出来。