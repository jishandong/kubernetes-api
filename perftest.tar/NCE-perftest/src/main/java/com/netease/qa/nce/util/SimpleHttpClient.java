package com.netease.qa.nce.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.log4j.Logger;


/**
 * http操作，返回Http响应码、响应体
 */
public class SimpleHttpClient {
	
	private static Logger logger = Logger.getLogger(SimpleHttpClient.class);

	private  HttpClient httpClient;
	
	public SimpleHttpClient(){
		this.httpClient = new DefaultHttpClient();
		this.httpClient.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, 60000);
		this.httpClient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT, 60000);
	}
	
	
	/**
	 * GET 
	 */
	public String[] get(String url, Header[] headers){
		HttpGet httpGet = new HttpGet(url);
		if (headers != null && headers.length != 0) {
			httpGet.setHeaders(headers);
		}
		try {
			HttpResponse httpResponse = httpClient.execute(httpGet);
			logger.info("GET. URL= " + url);
			String [] result = new String [2];
			result[0] =  String.valueOf(httpResponse.getStatusLine().getStatusCode());
			result[1] =  getResponse(httpResponse);
			return result;
		} catch (Exception e) {
			logger.error(e);
			return null;
		}
	}
	
	public String[] getNoResp(String url, Header[] headers) {
		HttpGet httpGet = new HttpGet(url);
		if ((headers != null) && (headers.length != 0))
			httpGet.setHeaders(headers);
		try {
			HttpResponse httpResponse = this.httpClient.execute(httpGet);
			logger.info("GET. URL= " + url);
			String[] result = new String[2];
			result[0] = String.valueOf(httpResponse.getStatusLine()
					.getStatusCode());
			result[1] = "";
			httpResponse.getEntity().consumeContent();
			return result;
		} catch (Exception e) {
			logger.error(e);
		}
		return null;
	}
	
	/** 
	 * POST
	 */
	public String[] post(String url, Header[] headers, HttpEntity httpEntity){
		HttpPost httpPost = new HttpPost(url);
		if (headers != null && headers.length != 0) {
			httpPost.setHeaders(headers);
		}
		if (httpEntity != null) {
			httpPost.setEntity(httpEntity);
		}
		try {
			HttpResponse httpResponse = httpClient.execute(httpPost);
			logger.info("POST. URL= " + url);
			String [] result = new String [2];
			result[0] =  String.valueOf(httpResponse.getStatusLine().getStatusCode());
			result[1] =  getResponse(httpResponse);
			return result;
		} catch (Exception e) {
			logger.error(e);
			return null;
		}
	}

	
	/**
	 * PUT
	 */
	public String[] put(String url, Header[] headers, HttpEntity httpEntity) {
		HttpPut httpPut = new HttpPut(url);
		if (headers != null && headers.length != 0) {
			httpPut.setHeaders(headers);
		}
		if (httpEntity != null) {
			httpPut.setEntity(httpEntity);
		}
		try {
			HttpResponse httpResponse = httpClient.execute(httpPut);
			logger.info("PUT. URL= " + url);
			String [] result = new String [2];
			result[0] =  String.valueOf(httpResponse.getStatusLine().getStatusCode());
			result[1] =  getResponse(httpResponse);
			return result;
		} catch (Exception e) {
			logger.error(e);
			return null;
		}
	}
	
	
	/**
	 * DELETE
	 */
	public String[] delete(String url, Header[] headers) {
		HttpDelete httpDelete = new HttpDelete(url);
		if (headers != null && headers.length != 0) {
			httpDelete.setHeaders(headers);
		}
		try {
			HttpResponse httpResponse = httpClient.execute(httpDelete);
			logger.info("DELETE. URL= " + url);
			String [] result = new String [2];
			result[0] =  String.valueOf(httpResponse.getStatusLine().getStatusCode());
			result[1] =  getResponse(httpResponse);
			return result;
		} catch (Exception e) {
			logger.error(e);
			return null;
		}
	}
	
	
	private String getResponse(HttpResponse httpResponse) throws IOException {
		String response = "";
		HttpEntity httpEntity = httpResponse.getEntity();
		BufferedReader reader = new BufferedReader(new InputStreamReader(httpEntity.getContent(), "UTF-8"));
		String str = null;
		while ((str = reader.readLine()) != null)
			response += str;
		return response;
	}

}
