package com.netease.qa.nce.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.log4j.Logger;

public class Template {

	private static Logger logger = Logger.getLogger(Template.class);
	private static final String Template = "template.json";
	private static JSONObject pods;
	private static JSONObject replicationcontrollers;
	private static JSONObject namespaces;
	private static JSONObject services;
	private static JSONObject endpoints;
	private static JSONObject serviceaccounts;
	private static JSONObject secrets;
	private static JSONObject nodes;
	private static JSONObject events;
	private static JSONObject bindings;

	public static JSONObject get(String type){
		if(type.equals("pods"))
			return pods;
		else if(type.equals("replicationcontrollers"))
			return replicationcontrollers;
		else if(type.equals("namespaces"))
			return namespaces;
		else if(type.equals("services"))
			return services;
		else if(type.equals("endpoints"))
			return endpoints;
		else if(type.equals("serviceaccounts"))
			return serviceaccounts;
		else if(type.equals("secrets"))
			return secrets;
		else if(type.equals("nodes"))
			return nodes;
		else if(type.equals("events"))
			return events;
		else if(type.equals("bindings"))
			return bindings;
		else{
			logger.error("wrong input");
			return null;
		}
	}
	
	
	static {
		String template = "";
		BufferedReader reader;
		try {
			reader = new BufferedReader(new InputStreamReader(
					new FileInputStream(new File(Template)), "UTF-8"));
			String str = null;
			while ((str = reader.readLine()) != null)
				template += str;
		} catch (Exception e) {
			logger.error(e);
		}

		JSONArray jsonArray = JSONArray.fromObject(template);
		pods = jsonArray.getJSONObject(0);
		replicationcontrollers = jsonArray.getJSONObject(1);
		namespaces = jsonArray.getJSONObject(2);
		services = jsonArray.getJSONObject(3);
		serviceaccounts = jsonArray.getJSONObject(4);
		endpoints = jsonArray.getJSONObject(5);
		secrets = jsonArray.getJSONObject(6);
		bindings = jsonArray.getJSONObject(7);
		nodes = jsonArray.getJSONObject(8);
		events= jsonArray.getJSONObject(9);

		logger.debug("pod" + pods);
		logger.debug("rc" + replicationcontrollers);
		logger.debug("namespace" + namespaces);
		logger.debug("service" + services);
		logger.debug("serviceaccount" + serviceaccounts);
		logger.debug("endpoint" + endpoints);
		logger.debug("secret" + secrets);
		logger.debug("binding" + bindings);
		logger.debug("node" + nodes);
		logger.debug("event" + events);
	}

	
	public static void main(String []args){
		
	}
	
}
