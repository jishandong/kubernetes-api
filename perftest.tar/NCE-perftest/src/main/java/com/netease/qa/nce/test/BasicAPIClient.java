package com.netease.qa.nce.test;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.UUID;
import java.util.List;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.apache.http.Header;
import org.apache.http.entity.StringEntity;
import org.apache.http.message.BasicHeader;
import org.apache.log4j.Logger;

import com.netease.qa.nce.util.SimpleHttpClient;
import com.netease.qa.nce.util.Template;
import com.netease.qa.nce.util.UrlTools;

public class BasicAPIClient {

	private String baseUrl = "http://192.168.145.128:8080/api/v1";
//	private String baseUrl = "https://115.236.124.215:6443/api/v1";
	private Header[] headers;
	private SimpleHttpClient simpleHttpClient;
	private static Logger logger = Logger.getLogger(BasicAPIClient.class);

	public BasicAPIClient() {
		this.simpleHttpClient = new SimpleHttpClient();
		this.headers = generateHeader();
	}

	public static void main(String []args){
		BasicAPIClient c = new BasicAPIClient();
		
		String resourceType = "replicationcontrollers";
		String resourceName = "zwj-008";
		String namespace = "default";
		
		boolean r = c.createResource(resourceType, resourceName, namespace);
		logger.info(r);
		
		r = c.getResource(resourceType, resourceName, namespace, "");
		logger.info(r);
		
		r = c.getResource("pods", "", namespace, "name="+resourceName);
		logger.info(r);
		
		r = c.deleteResource(resourceType, resourceName, namespace);
		logger.info(r);
		
		c.cleanAllRC(namespace);

	}
	
	public boolean getResourceNoRsp(String resourceType, String resourceName, String namespace, String labelSelector)
	  {
	    UrlTools urlTools = new UrlTools(this.baseUrl);
	    if (StringUtils.isEmpty(namespace)) {
	      urlTools.addPath(resourceType).addPath(resourceName);
	    }
	    else {
	      urlTools.addPath("namespaces").addPath(namespace).addPath(resourceType).addPath(resourceName);
	    }
	    if (!StringUtils.isEmpty(labelSelector)) {
	      urlTools.addQueryParam("labelSelector", labelSelector);
	    }

	    String[] result = this.simpleHttpClient.getNoResp(urlTools.getCompleteUrl(), this.headers);
	    if (result == null) {
	      return false;
	    }
	    if (!result[0].equals("200")) {
	      logger.error("ERROR, code=" + result[0] + "\n" + result[1]);
	      return false;
	    }
	    return true;
	  }
	
	public boolean getResource(String resourceType, String resourceName, String namespace, String labelSelector) {
		UrlTools urlTools = new UrlTools(baseUrl);
		if (StringUtils.isEmpty(namespace)) {
			urlTools.addPath(resourceType).addPath(resourceName);
		} 
		else {
			urlTools.addPath("namespaces").addPath(namespace).addPath(resourceType).addPath(resourceName);
		}
		if(!StringUtils.isEmpty(labelSelector)){
			urlTools.addQueryParam("labelSelector", labelSelector);
		}
		
		String [] result = simpleHttpClient.get(urlTools.getCompleteUrl(), headers);
		if(result == null){
			return false;
		}
		if(!result[0].equals("200")){
			logger.error("ERROR, code=" + result[0] + "\n"+ result[1]);
			return false;
		}
		return true;
	}

	
	public String getResourceAndReturn(String resourceType, String resourceName, String namespace, String labelSelector) {
		UrlTools urlTools = new UrlTools(baseUrl);
		if (StringUtils.isEmpty(namespace)) {
			urlTools.addPath(resourceType).addPath(resourceName);
		} 
		else {
			urlTools.addPath("namespaces").addPath(namespace).addPath(resourceType).addPath(resourceName);
		}
		if(!StringUtils.isEmpty(labelSelector)){
			urlTools.addQueryParam("labelSelector", labelSelector);
		}
		
		String [] result = simpleHttpClient.get(urlTools.getCompleteUrl(), headers);
		if(result == null){
			return null;
		}
		if(!result[0].equals("200")){
			logger.error("ERROR, code=" + result[0] + "\n"+ result[1]);
			return null;
		}
		return result[1];
	}
	
	
	public boolean createResource(String resourceType, String resourceName, String namespace) {  
		UrlTools urlTools = new UrlTools(baseUrl);
		if (StringUtils.isEmpty(namespace)){
			urlTools.addPath(resourceType);
		}
		else{
			urlTools.addPath("namespaces").addPath(namespace).addPath(resourceType);
		}
		StringEntity entity;
		try {
			String body = Template.get(resourceType).toString().replaceAll("default-resource-name", resourceName);
			if(resourceType.equals("replicationcontrollers")){
				//rc 要保证rc和模板中的pod的lable一致，才能根据lable查询由他创建的pod。
				//rc自己metadata.labels无所谓    因为没人会去管理 他
				body = body.replaceAll("default-resource-label-name", resourceName); 
				body = body.replaceAll("\"default-replicas\"", "1");
				body = body.replaceAll("default-namespace", namespace);
				logger.info(body);
			}
			entity = new StringEntity(body);
		} catch (UnsupportedEncodingException e) {
			logger.error(e);
			return false;
		}
		
		String [] result = simpleHttpClient.post(urlTools.getCompleteUrl(), headers, entity);
		if(result == null){
			return false;
		}
		if(!result[0].equals("201")){
			logger.error("ERROR, code=" + result[0] + "\n"+ result[1]);
			return false;
		}
		return true;
	}
	
	
	public boolean createResource(String resourceType, String resourceName, String namespace, String replicas) {  
		UrlTools urlTools = new UrlTools(baseUrl);
		if (StringUtils.isEmpty(namespace)){
			urlTools.addPath(resourceType);
		}
		else{
			urlTools.addPath("namespaces").addPath(namespace).addPath(resourceType);
		}
		StringEntity entity;
		try {
			String body = Template.get(resourceType).toString().replaceAll("default-resource-name", resourceName);
			if(resourceType.equals("replicationcontrollers")){
				//rc 要保证rc和模板中的pod的lable一致，才能根据lable查询由他创建的pod。
				//rc自己metadata.labels无所谓    因为没人会去管理 他
				body = body.replaceAll("default-resource-label-name", resourceName); 
				body = body.replaceAll("\"default-replicas\"", replicas);
				logger.info(body);
			}
			entity = new StringEntity(body);
		} catch (UnsupportedEncodingException e) {
			logger.error(e);
			return false;
		}
		
		String [] result = simpleHttpClient.post(urlTools.getCompleteUrl(), headers, entity);
		if(result == null){
			return false;
		}
		if(!result[0].equals("201")){
			logger.error("ERROR, code=" + result[0] + "\n"+ result[1]);
			return false;
		}
		return true;
	}

	
	/**
	 * 更新资源
	 * @param resourceType
	 * @param resourceName
	 * @param namespace
	 * @param replicas。   replicationcontrollers更新专用，更新副本数
	 * @return
	 */
	public boolean replaceResource(String resourceType, String resourceName, String namespace, String replicas) {
		UrlTools urlTools = new UrlTools(baseUrl);
		if (StringUtils.isEmpty(namespace)){
			urlTools.addPath(resourceType).addPath(resourceName);
		}
		else{
			urlTools.addPath("namespaces").addPath(namespace).addPath(resourceType).addPath(resourceName);
		}
		StringEntity entity;
		try {
			String body = Template.get(resourceType).toString().replaceAll("default-resource-name", resourceName);
			if(resourceType.equals("replicationcontrollers")){
				//rc 要保证rc和模板中的pod的lable一致，才能根据lable查询由他创建的pod。
				//rc自己metadata.labels无所谓    因为没人会去管理 他
				body = body.replaceAll("default-resource-label-name", resourceName); 
				body = body.replaceAll("\"default-replicas\"", replicas);
				body = body.replaceAll("default-namespace", namespace);
				logger.info(body);
			}
			entity = new StringEntity(body);
		} catch (UnsupportedEncodingException e) {
			logger.error(e);
			return false;
		}
		
		String [] result = simpleHttpClient.put(urlTools.getCompleteUrl(), headers, entity);
		if(result == null){
			return false;
		}
		if(!result[0].equals("200")){
			logger.error("ERROR, code=" + result[0] + "\n"+ result[1]);
			return false;
		}
		return true;
	}

	
	public boolean deleteResource(String resourceType, String resourceName, String namespace) {
		UrlTools urlTools = new UrlTools(baseUrl);
		if (StringUtils.isEmpty(namespace)){
			urlTools.addPath(resourceType).addPath(resourceName);
		}
		else{
			urlTools.addPath("namespaces").addPath(namespace).addPath(resourceType).addPath(resourceName);
		}

		String [] result = simpleHttpClient.delete(urlTools.getCompleteUrl(), headers);
		if(result == null){
			return false;
		}
		if(!result[0].equals("200")){
			logger.error("ERROR, code=" + result[0] + "\n"+ result[1]);
			return false;
		}
		return true;	
		
	}

	
	/**
	 * 缩容并删除所有rc，用于测试进程定时中止时，清理环境
	 * @param namespace
	 * @return
	 */
	public boolean cleanAllRC(String namespace){
		String response = getResourceAndReturn("replicationcontrollers", "", namespace, "");
		logger.info("============clean all rc=============");
		boolean result = true;
		JSONArray rcList = JSONObject.fromObject(response).getJSONArray("items");
		if(rcList.size() == 0){
			logger.info("no rc exsit");
			return true;
		}
		for(int i = 0; i < rcList.size(); ++i){
			String rcName = rcList.getJSONObject(i).getJSONObject("metadata").getString("name");
			if(!replaceResource("replicationcontrollers", rcName, namespace, "0")){
				result = false;
			}
			if(!deleteResource("replicationcontrollers", rcName, namespace)){
				result = false;
			}
		}
		return result;
	}
	
	/**
	 * 删除除了水位以外新增加的rc，用于测试进程定时终止的时候，清理环境，保持水位
	 * @param rcName
	 * @param namespace
	 * @return
	 */
	public void deleteNewAddedRC(String rcName, String namespace) {
		if(getResource("replicationcontrollers", rcName, namespace, "")) {
			replaceResource("replicationcontrollers", rcName, namespace, "0");
			deleteResource("replicationcontrollers", rcName, namespace);
			logger.info("clean " + rcName);
		} else {
			logger.info(rcName + " already cleaned");
		}
	}
	
	/**
	 * 删除除了水位以外新增加的rc，用于测试进程定时终止的时候，清理环境，保持水位
	 * @param rcName
	 * @param namespace
	 * @return
	 */
	public void deleteNewAddedRC(String [] rcNames, String namespace) {
		for(String rcName : rcNames){
			if(getResource("replicationcontrollers", rcName, namespace, "")) {
				replaceResource("replicationcontrollers", rcName, namespace, "0");
				deleteResource("replicationcontrollers", rcName, namespace);
				logger.info("clean " + rcName);
			} else {
				logger.info(rcName + " already cleaned");
			}
		}
	}
	
	/**
	 * 
	 */
	public void deleteNewAddedRC(String[] nsAndRcs) {
		for(String ns_rc : nsAndRcs) {
			String ns = ns_rc.split(":")[0];
			String rc = ns_rc.split(":")[1];
			if(getResource("replicationcontrollers", rc, ns, "")) {
				replaceResource("replicationcontrollers", rc, ns, "0");
				deleteResource("replicationcontrollers", rc, ns);
				logger.info("clean " + rc);
			} else {
				logger.info(rc + " already cleaned");
			}
		}
	}
	
	/**
	 * request header
	 */
	private Header[] generateHeader() {
		List<Header> list = new ArrayList<Header>();
		list.add(new BasicHeader("Content-type", "application/json"));
		list.add(new BasicHeader("Accept", "application/json"));
		list.add(new BasicHeader("Connection", "Keep-Alive"));
		list.add(new BasicHeader(
				"User-Agent",
				"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.103 Safari/537.36"));
		list.add(new BasicHeader("X-RequestId", UUID.randomUUID().toString()));
		return list.toArray(new Header[] {});
	}

}
