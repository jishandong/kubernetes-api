package com.netease.qa.nce.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

/**
 * URL拼接工具
 */
public class UrlTools {
	
	private String host;
	private List<String> pathes;
	private Map<String, String> queryParam; 
	
	
	public UrlTools(String host){
		this.setHost(host);
	}
	
	public String getHost() {
		return this.host;
	}

	public void setHost(String host) {
		this.host = host;
	}
	
	public UrlTools addPath(String path) {
		if(pathes == null){
			pathes = new ArrayList<String>();
		}
		if(!StringUtils.isEmpty(path)){
			pathes.add(path);
		}
		return this;
	}
	
	public String getPath() {
		String allPath = "";
		for(String path : pathes){
			path = path.trim();
			allPath += ("/" + path);
		}
		return allPath;
	}
	
	
	public Map<String, String> getQueryParam() {
		return this.queryParam;
	}
	
	
	public void setQueryParam(Map<String, String> queryParam) {
		this.queryParam = queryParam;
	}
	
	
	public void addQueryParam(String key, String value) {
		if (queryParam == null) 
			queryParam = new HashMap<String, String>();
		if(value != null)
			queryParam.put(key, value);
	}
	
	
	public String getCompleteUrl(){
		StringBuilder sb = new StringBuilder(host);
		sb.append(getPath());
		
		if(queryParam != null && queryParam.size() > 0){
			Set<String> keys = queryParam.keySet();
			Iterator<String> it = keys.iterator(); 
			if(it.hasNext()){
				String key = it.next();
				String value = queryParam.get(key);
				sb.append("?").append(key + "=").append(value);
			}
			while (it.hasNext()) {
				String key = it.next();
				String value = queryParam.get(key);
				sb.append("&").append(key + "=").append(value);
			}
		}
		
		return sb.toString();
	}
	
	
	public static void main(String [] asd){
		UrlTools help = new UrlTools("http://115.236.124.215:8080/api/v1");
		help.addPath("aaa").addPath("bbb").addPath("ccc");
		help.addPath("aaa").addPath("bbb").addPath("ccc");
		help.addQueryParam("identifier", "123123");
		help.addQueryParam("module", "456789");
		help.addQueryParam("sta", null);
		System.out.println(help.getCompleteUrl());
	}
}

