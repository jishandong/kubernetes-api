package com.netease.qa.nce.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.log4j.Logger;

/**
 * 调用后轮询，直到异步操作成功。 模拟同步接口。 
 * @author hzzhangweijie
 */
public class SyncAPIClient {

	private BasicAPIClient basicAPIClient;
	private static Logger logger = Logger.getLogger(SyncAPIClient.class);
	private static final int QUERY_INTERVAL = 10000;  //轮询间隔
	private static final int QUERY_TIMEOUT = 600000;  //轮询超时，平台目前是600秒超时
	private static final String TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS";
	private static final String TIME_ZONE = "GMT";
	
	
	public SyncAPIClient() {
		this.basicAPIClient = new BasicAPIClient();
	}

	public static void main(String []args){
		SyncAPIClient c = new SyncAPIClient();
		String rcName = "wyz-test";
		String namespace = "default";
		
		c.createRCWaitRunning(rcName, namespace);
		c.updateRCNew(rcName, namespace, "1");

//		c.updateRC(rcName, "perf1", "1");
		
	}
	
	
	/**
	 * 创建rc，副本数固定=1
	 * @param rcName
	 * @param namespace
	 * @return
	 */
	public boolean createRCWaitRunning(String rcName, String namespace){
		//create rc
		Long rcSendTime = System.currentTimeMillis();
		boolean result = basicAPIClient.createResource("replicationcontrollers", rcName, namespace);
		if(!result){
			logger.error("create rc error");
			return false;
		}
		//query every 5 seconds
		int wait_time = 0;
		while(wait_time < QUERY_TIMEOUT){
			String pods = basicAPIClient.getResourceAndReturn("pods", "", namespace, "name=" + rcName);
			JSONObject json = JSONObject.fromObject(pods);
			if(null == json) {
				logger.error("can not get json from pod info");
				continue;
			}
			JSONArray podlist = json.getJSONArray("items");
			logger.info("pods list: " + podlist.toString());

			if(podlist.size() != 1){
				logger.info("replicas: 1, now: " + podlist.size() + ". pods not all created, wait " + wait_time/1000 + "s...");
			}
			else {
				String phase = podlist.getJSONObject(0).getJSONObject("status").getString("phase");
				//获取pod信息中的分段打点时间
				if(phase.equals("Running")){
					logger.info("pods is running, ok!");
					
//					if(!podlist.getJSONObject(0).getJSONObject("metadata").getJSONObject("annotations").containsKey("netease.com/controller-rcEnSmartqueue-time")) {
//						logger.error("can not get controller-rcEnSmartQueue-time from pod json");
//						return false; // 规避@小强的时间打点bug
////						continue;
//					}																								 
//					if(!podlist.getJSONObject(0).getJSONObject("metadata").getJSONObject("annotations").containsKey("netease.com/scheduler-bindSend-time")) {
//						logger.error("can not get netease.com/scheduler-bindSend-time from pod json");
//						return false; // 规避@小强的时间打点bug
////						continue;
//					}
//					if(!podlist.getJSONObject(0).getJSONObject("metadata").getJSONObject("annotations").containsKey("kubernetes.io/config.seen")) {
//						logger.error("can not get kubernetes.io/config.seen from pod json");
//						return false; // 规避@小强的时间打点bug
////						continue;
//					}
//					
//					String configSeenTime = podlist.getJSONObject(0).getJSONObject("metadata").getJSONObject("annotations").getString("kubernetes.io/config.seen").substring(0, 23);
//					String rcCreateTime = podlist.getJSONObject(0).getJSONObject("metadata").getJSONObject("annotations").getString("netease.com/controller-rcCreate-time").substring(0, 23);
//					String podWriteTime = podlist.getJSONObject(0).getJSONObject("metadata").getString("creationTimestamp").substring(0, 23);
//					String rcEnSmartQueueTime = podlist.getJSONObject(0).getJSONObject("metadata").getJSONObject("annotations").getString("netease.com/controller-rcEnSmartqueue-time").substring(0, 23);
//					String rcEnqueueTime = podlist.getJSONObject(0).getJSONObject("metadata").getJSONObject("annotations").getString("netease.com/controller-rcEnqueue-time").substring(0, 23);
//					String rcDequeueTime = podlist.getJSONObject(0).getJSONObject("metadata").getJSONObject("annotations").getString("netease.com/controller-rcDequeue-time").substring(0, 23);
//					if(!podlist.getJSONObject(0).getJSONObject("metadata").getJSONObject("annotations").containsKey("netease.com/kubelet-syncStart-time")) {
//						logger.error("can not get kubelet-syncStart-time from pod json");
//						return false; // 规避@小强的时间打点bug
////						continue;
//					}
//					String syncStartTime = podlist.getJSONObject(0).getJSONObject("metadata").getJSONObject("annotations").getString("netease.com/kubelet-syncStart-time").substring(0, 23);
//					String syncEndTime = podlist.getJSONObject(0).getJSONObject("metadata").getJSONObject("annotations").getString("netease.com/kubelet-syncEnd-time").substring(0, 23);
//					String bindSendTime = podlist.getJSONObject(0).getJSONObject("metadata").getJSONObject("annotations").getString("netease.com/scheduler-bindSend-time").substring(0, 23);
//					String scheduleStartTime = podlist.getJSONObject(0).getJSONObject("metadata").getJSONObject("annotations").getString("netease.com/scheduler-scheduleStart-time").substring(0, 23);
//					String scheduleEndTime = podlist.getJSONObject(0).getJSONObject("metadata").getJSONObject("annotations").getString("netease.com/scheduler-scheduleEnd-time").substring(0, 23);
//					String containerRunTime = podlist.getJSONObject(0).getJSONObject("status").getJSONArray("containerStatuses").getJSONObject(0).getJSONObject("state").getJSONObject("running").getString("startedAt").substring(0, 23);
//					
//					logger.debug("rcWriteTime: " + rcCreateTime);
//					logger.debug("podWriteTime: " + podWriteTime);
//					logger.debug("bindingWriteTime: " + bindSendTime);
//					logger.debug("containerRunTime: " + containerRunTime);
//					try {
//						SimpleDateFormat sdf = new SimpleDateFormat(TIME_FORMAT);
//						sdf.setTimeZone(TimeZone.getTimeZone(TIME_ZONE));
//						Date date1 = sdf.parse(rcCreateTime);
//						Date date1_1 = sdf.parse(rcEnSmartQueueTime);
//						Date date2 = sdf.parse(rcEnqueueTime);
//						Date date3 = sdf.parse(rcDequeueTime);
//						Date date4 = sdf.parse(podWriteTime);
//						Date date5 = sdf.parse(scheduleStartTime);
//						Date date6 = sdf.parse(scheduleEndTime);
//						Date date7 = sdf.parse(bindSendTime);
//						Date date7_1 = sdf.parse(configSeenTime);
//						Date date8 = sdf.parse(syncStartTime); 
//						Date date9 = sdf.parse(syncEndTime);
//						
//						logger.info("rcCreateTime : " + date1 + " " + rcName);
//						logger.info("rcEnSmartQueueTime : " + date1_1 + " " + rcName);
//						logger.info("rcEnqueue : " + date2 + " " + rcName);
//						logger.info("rcDequeue : " + date3 + " " + rcName);
//						logger.info("podWriteTime : " + date4 + " " + rcName);
//						logger.info("scheduleStartTime : " + date5 + " " + rcName);
//						logger.info("scheduleEndTime : " + date6 + " " + rcName);
//						logger.info("bindSendTime : " + date7 + " " + rcName);
//						logger.info("configSeenTime : " + date7_1 + " " + rcName);
//						logger.info("syncStartTime : " + date8 + " " + rcName);
//						logger.info("syncEndTime : " + date9 + " " + rcName);
//						
//						
//						logger.info("USETIME rc write " + (date1.getTime() - rcSendTime) + " " + rcName);
//						logger.info("USETIME watch and list " + (date1_1.getTime() - date1.getTime()) + " " + rcName);
//						logger.info("USETIME rc in smartQueue " + (date2.getTime() - date1_1.getTime()) + " " + rcName);
////						logger.info("USETIME watch and list and rc in smartQueue " + (date2.getTime() - date1.getTime()) + " " + rcName);
//						logger.info("USETIME rc in queue " + (date3.getTime() - date2.getTime()) + " " + rcName);
//						logger.info("USETIME rc cal and pod write " + (date4.getTime() - date3.getTime()) + " " + rcName);
//						logger.info("USETIME pod in queue " + (date5.getTime() - date4.getTime()) + " " + rcName);
//						logger.info("USETIME calculate schedule " + (date6.getTime() - date5.getTime()) + " " + rcName);
////						logger.info("USETIME binding write " + (date8.getTime() - date7.getTime()) + " " + rcName);
//						logger.info("USETIME binding write " + (date7_1.getTime() - date7.getTime()) + " " + rcName);
//						logger.info("USETIME kubelet_time_before_running " + (date8.getTime() - date7_1.getTime()) + " " + rcName);
//						logger.info("USETIME container run " + (date9.getTime() - date8.getTime()) + " " + rcName);
//					} catch (ParseException e) { 
//						logger.error("convert time error", e);
//						return false;
//					}
					return true;
				}
				else{
					logger.info("pods is pending, wait " + wait_time/1000 + "s...");
				}
			}
			try {
				Thread.sleep(QUERY_INTERVAL);
			} catch (InterruptedException e) { 
				logger.error(e); 
				return false;
			}
			wait_time += QUERY_INTERVAL;
		}
		logger.error(QUERY_TIMEOUT + "used, create rc timeout!");//超时时间内未退出，算超时
		return false;
	}
	
	/**
	 * 创建rc，副本数固定=1
	 * @param rcName
	 * @param namespace
	 * @return
	 */
	public boolean createRC(String rcName, String namespace){
		//create rc
		Long rcSendTime = System.currentTimeMillis();
		boolean result = basicAPIClient.createResource("replicationcontrollers", rcName, namespace);
		if(!result){
			logger.error("create rc error");
			return false;
		}
		//query every 5 seconds
		int wait_time = 0;
		while(wait_time < QUERY_TIMEOUT){
			String pods = basicAPIClient.getResourceAndReturn("pods", "", namespace, "name=" + rcName);
			JSONObject json = JSONObject.fromObject(pods);
			JSONArray podlist = json.getJSONArray("items");
			logger.info("pods list: " + podlist.toString());
			
			if(podlist.size() != 1){
				logger.info("replicas: 1, now: " + podlist.size() + ". pods not all created, wait " + wait_time/1000 + "s...");
			}
			else {
				String phase = podlist.getJSONObject(0).getJSONObject("status").getString("phase");
				if(phase.equals("Pending")) {
					return true;
				}
				else {
					try {
						Thread.sleep(QUERY_INTERVAL);
					} catch (InterruptedException e) { 
						logger.error(e); 
						return false;
					}
					wait_time += QUERY_INTERVAL;
				}
			}
		}
		logger.error(QUERY_TIMEOUT + "used, create rc timeout!");//超时时间内未退出，算超时
		return false;
	}
	
	
	
	/**
	 * 更新rc，更新副本数
	 * @param rcName
	 * @param namespace
	 * @param replicas
	 * @return
	 */
	public boolean updateRC(String rcName, String namespace, String replicas){
		//update rc
		Long rcSendTime = System.currentTimeMillis();
		boolean result = basicAPIClient.replaceResource("replicationcontrollers", rcName, namespace, replicas);
		Long rcUpdateTime = System.currentTimeMillis(); //api响应时间，约等于rc数据被写入etcd的时间
		if(!result){
			logger.error("update rc error");
			return false;
		}
		//query every 5 seconds
		int wait_time = 0;
		while(wait_time < QUERY_TIMEOUT){
			String pods = basicAPIClient.getResourceAndReturn("pods", "", namespace, "name=" + rcName);
			JSONObject json = JSONObject.fromObject(pods);
			JSONArray podlist = json.getJSONArray("items");
			logger.info("pods list: " + podlist.toString());
			if(podlist.size() != Integer.valueOf(replicas)){
				logger.info("replicas: " + replicas + ", now: " + podlist.size() + ". pods not all created or delete, wait " + wait_time/1000 + "s...");
			}
			else{
				//目标是缩容至0时，直接认为ok
				if(replicas.equals("0")){
					return true;
				}
				//如果目标副本数不为零， 需要检查是否都running
				boolean allRunning = false;
				for (int i = 0; i < podlist.size(); ++i) {
					String phase = podlist.getJSONObject(i).getJSONObject("status").getString("phase");
					if (!phase.equals("Running")) {
						logger.info("some pods is pending, wait " + wait_time / 1000 + "s...");
						allRunning = false;
						break;
					}
					if (i == podlist.size() - 1)
						allRunning = true; // 全部都已经是running状态了
				}
				//都running, 获取pod信息中的分段打点时间
				if(allRunning){
					for(int i = 0; i < podlist.size(); ++i){
//						String rcWriteTime = podlist.getJSONObject(i).getJSONObject("metadata").getJSONObject("annotations").getString("kubernetes.io/rc-created-time").substring(0, 23);
//						String podWriteTime = podlist.getJSONObject(i).getJSONObject("metadata").getString("creationTimestamp").substring(0, 23);
//						String bindingWriteTime = podlist.getJSONObject(i).getJSONObject("metadata").getJSONObject("annotations").getString("kubernetes.io/binding-write-time").substring(0, 23);
//						String containerRunTime = podlist.getJSONObject(i).getJSONObject("status").getJSONArray("containerStatuses").getJSONObject(0).getJSONObject("state").getJSONObject("running").getString("startedAt").substring(0, 23);
						
						String rcCreateTime = podlist.getJSONObject(0).getJSONObject("metadata").getJSONObject("annotations").getString("netease.com/controller-rcCreate-time").substring(0, 23);
						String podWriteTime = podlist.getJSONObject(0).getJSONObject("metadata").getString("creationTimestamp").substring(0, 23);
						String rcEnqueueTime = podlist.getJSONObject(0).getJSONObject("metadata").getJSONObject("annotations").getString("netease.com/controller-rcEnqueue-time").substring(0, 23);
						String rcDequeueTime = podlist.getJSONObject(0).getJSONObject("metadata").getJSONObject("annotations").getString("netease.com/controller-rcDequeue-time").substring(0, 23);
						String syncStartTime = podlist.getJSONObject(0).getJSONObject("metadata").getJSONObject("annotations").getString("netease.com/kubelet-syncStart-time").substring(0, 23);
						String syncEndTime = podlist.getJSONObject(0).getJSONObject("metadata").getJSONObject("annotations").getString("netease.com/kubelet-syncEnd-time").substring(0, 23);
						String bindSendTime = podlist.getJSONObject(0).getJSONObject("metadata").getJSONObject("annotations").getString("netease.com/scheduler-bindSend-time").substring(0, 23);
						String scheduleStartTime = podlist.getJSONObject(0).getJSONObject("metadata").getJSONObject("annotations").getString("netease.com/scheduler-scheduleStart-time").substring(0, 23);
						String scheduleEndTime = podlist.getJSONObject(0).getJSONObject("metadata").getJSONObject("annotations").getString("netease.com/scheduler-scheduleEnd-time").substring(0, 23);
						String containerRunTime = podlist.getJSONObject(0).getJSONObject("status").getJSONArray("containerStatuses").getJSONObject(0).getJSONObject("state").getJSONObject("running").getString("startedAt").substring(0, 23);
						
						logger.debug("rcWriteTime: " + rcCreateTime);
						logger.debug("podWriteTime: " + podWriteTime);
						logger.debug("bindingWriteTime: " + bindSendTime);
						logger.debug("containerRunTime: " + containerRunTime);
						try {
							SimpleDateFormat sdf = new SimpleDateFormat(TIME_FORMAT);
							sdf.setTimeZone(TimeZone.getTimeZone(TIME_ZONE));  
//							Date date1 = sdf.parse(rcCreateTime);
//							Date date2 = sdf.parse(podWriteTime);
//							Date date3 = sdf.parse(bindSendTime);
//							Date date4 = sdf.parse(containerRunTime);
							
//							Date date1 = sdf.parse(rcCreateTime);
//							Date date2 = sdf.parse(rcEnqueueTime);
//							Date date3 = sdf.parse(rcDequeueTime);
							Date date1 = sdf.parse(podWriteTime);
							Date date2 = sdf.parse(scheduleStartTime);
							Date date3 = sdf.parse(scheduleEndTime);
							Date date4 = sdf.parse(bindSendTime);
							Date date5 = sdf.parse(syncStartTime); 
							Date date6 = sdf.parse(syncEndTime);
							
							if(date2.getTime() - rcUpdateTime > 0){// pod列表中，有一个pod是扩容之前就已经创建的，所以pod写入时间较久远，相减为负数，需要排除
//								logger.info("rcWriteTime: " + date1);
//								logger.info("rcUpdateTime: " + new Date(rcUpdateTime));
//								logger.info("podWriteTime: " + date2);
//								logger.info("bindingWriteTime: " + date3);
//								logger.info("containerRunTime: " + date4);
								logger.info("USETIME rc update " + (rcUpdateTime - rcSendTime));// 不能使用date1.getTime() - rcSendTime。   pod中的rcWriteTime只会记录rc创建的时间。 相减为负数
//								logger.info("USETIME pod write " + (date2.getTime() - rcUpdateTime)); 
//								logger.info("USETIME binding write " + (date3.getTime() - date2.getTime()));
//								logger.info("USETIME container run " + (date4.getTime() - date3.getTime()));
								
								logger.info("USETIME rc update + rc in queue+ rc cal and pod write " + (date1.getTime() - rcUpdateTime));
								logger.info("USETIME pod in queue " + (date2.getTime() - date1.getTime()));
								logger.info("USETIME calculate schedule " + (date3.getTime() - date2.getTime()));
								logger.info("USETIME binding write " + (date5.getTime() - date4.getTime()));
								logger.info("USETIME container run " + (date6.getTime() - date5.getTime()));
								
							}
						} catch (ParseException e) { 
							logger.error("convert time error", e);
							return false;
						}
					}
					return true;
				}
			}
			try {
				Thread.sleep(QUERY_INTERVAL);  
			} catch (InterruptedException e) { 
				logger.error(e); 
				return false;
			}
			wait_time += QUERY_INTERVAL;
		}
		logger.error(QUERY_TIMEOUT + "used, create rc timeout!"); //超时时间内未退出，算超时
		return false;
	}
	
	public boolean updateRCNew(String rcName, String namespace, String replicas){
		
		//update rc
		Long rcSendTime = System.currentTimeMillis();
		boolean result = basicAPIClient.replaceResource("replicationcontrollers", rcName, namespace, replicas);
		Long rcUpdateTime = System.currentTimeMillis(); //api响应时间，约等于rc数据被写入etcd的时间
		if(!result){
			logger.error("update rc error");
			return false;
		}
		//query every 5 seconds
		JSONObject rc = JSONObject.fromObject(basicAPIClient.getResourceAndReturn("replicationcontrollers", rcName, namespace, ""));
		System.out.println(rc);
		String generation = rc.getJSONObject("metadata").getString("generation");
		String specReplicas = rc.getJSONObject("spec").getString("replicas");
		String statusReplicas = rc.getJSONObject("status").getString("replicas");
		String observedGeneration = rc.getJSONObject("status").getString("observedGeneration");
		if(specReplicas == statusReplicas && generation == observedGeneration)
			System.out.println("true");
		int wait_time = 0;
//		while(wait_time < QUERY_TIMEOUT){
//			String pods = basicAPIClient.getResourceAndReturn("pods", "", namespace, "name=" + rcName);
//			JSONObject json = JSONObject.fromObject(pods);
//			JSONArray podlist = json.getJSONArray("items");
//			logger.info("pods list: " + podlist.toString());
//			if(podlist.size() != Integer.valueOf(replicas)){
//				logger.info("replicas: " + replicas + ", now: " + podlist.size() + ". pods not all created or delete, wait " + wait_time/1000 + "s...");
//			}
//			else{
//				//目标是缩容至0时，直接认为ok
//				if(replicas.equals("0")){
//					return true;
//				}
//				//如果目标副本数不为零， 需要检查是否都running
//				boolean allRunning = false;
//				for (int i = 0; i < podlist.size(); ++i) {
//					String phase = podlist.getJSONObject(i).getJSONObject("status").getString("phase");
//					if (!phase.equals("Running")) {
//						logger.info("some pods is pending, wait " + wait_time / 1000 + "s...");
//						allRunning = false;
//						break;
//					}
//					if (i == podlist.size() - 1)
//						allRunning = true; // 全部都已经是running状态了
//				}
//				//都running, 获取pod信息中的分段打点时间
//				if(allRunning){
//					for(int i = 0; i < podlist.size(); ++i){
////						String rcWriteTime = podlist.getJSONObject(i).getJSONObject("metadata").getJSONObject("annotations").getString("kubernetes.io/rc-created-time").substring(0, 23);
////						String podWriteTime = podlist.getJSONObject(i).getJSONObject("metadata").getString("creationTimestamp").substring(0, 23);
////						String bindingWriteTime = podlist.getJSONObject(i).getJSONObject("metadata").getJSONObject("annotations").getString("kubernetes.io/binding-write-time").substring(0, 23);
////						String containerRunTime = podlist.getJSONObject(i).getJSONObject("status").getJSONArray("containerStatuses").getJSONObject(0).getJSONObject("state").getJSONObject("running").getString("startedAt").substring(0, 23);
//						
//						String rcCreateTime = podlist.getJSONObject(0).getJSONObject("metadata").getJSONObject("annotations").getString("netease.com/controller-rcCreate-time").substring(0, 23);
//						String podWriteTime = podlist.getJSONObject(0).getJSONObject("metadata").getString("creationTimestamp").substring(0, 23);
//						String rcEnqueueTime = podlist.getJSONObject(0).getJSONObject("metadata").getJSONObject("annotations").getString("netease.com/controller-rcEnqueue-time").substring(0, 23);
//						String rcDequeueTime = podlist.getJSONObject(0).getJSONObject("metadata").getJSONObject("annotations").getString("netease.com/controller-rcDequeue-time").substring(0, 23);
//						String syncStartTime = podlist.getJSONObject(0).getJSONObject("metadata").getJSONObject("annotations").getString("netease.com/kubelet-syncStart-time").substring(0, 23);
//						String syncEndTime = podlist.getJSONObject(0).getJSONObject("metadata").getJSONObject("annotations").getString("netease.com/kubelet-syncEnd-time").substring(0, 23);
//						String bindSendTime = podlist.getJSONObject(0).getJSONObject("metadata").getJSONObject("annotations").getString("netease.com/scheduler-bindSend-time").substring(0, 23);
//						String scheduleStartTime = podlist.getJSONObject(0).getJSONObject("metadata").getJSONObject("annotations").getString("netease.com/scheduler-scheduleStart-time").substring(0, 23);
//						String scheduleEndTime = podlist.getJSONObject(0).getJSONObject("metadata").getJSONObject("annotations").getString("netease.com/scheduler-scheduleEnd-time").substring(0, 23);
//						String containerRunTime = podlist.getJSONObject(0).getJSONObject("status").getJSONArray("containerStatuses").getJSONObject(0).getJSONObject("state").getJSONObject("running").getString("startedAt").substring(0, 23);
//						
//						logger.debug("rcWriteTime: " + rcCreateTime);
//						logger.debug("podWriteTime: " + podWriteTime);
//						logger.debug("bindingWriteTime: " + bindSendTime);
//						logger.debug("containerRunTime: " + containerRunTime);
//						try {
//							SimpleDateFormat sdf = new SimpleDateFormat(TIME_FORMAT);
//							sdf.setTimeZone(TimeZone.getTimeZone(TIME_ZONE));  
////							Date date1 = sdf.parse(rcCreateTime);
////							Date date2 = sdf.parse(podWriteTime);
////							Date date3 = sdf.parse(bindSendTime);
////							Date date4 = sdf.parse(containerRunTime);
//							
////							Date date1 = sdf.parse(rcCreateTime);
////							Date date2 = sdf.parse(rcEnqueueTime);
////							Date date3 = sdf.parse(rcDequeueTime);
//							Date date1 = sdf.parse(podWriteTime);
//							Date date2 = sdf.parse(scheduleStartTime);
//							Date date3 = sdf.parse(scheduleEndTime);
//							Date date4 = sdf.parse(bindSendTime);
//							Date date5 = sdf.parse(syncStartTime); 
//							Date date6 = sdf.parse(syncEndTime);
//							
//							if(date2.getTime() - rcUpdateTime > 0){// pod列表中，有一个pod是扩容之前就已经创建的，所以pod写入时间较久远，相减为负数，需要排除
////								logger.info("rcWriteTime: " + date1);
////								logger.info("rcUpdateTime: " + new Date(rcUpdateTime));
////								logger.info("podWriteTime: " + date2);
////								logger.info("bindingWriteTime: " + date3);
////								logger.info("containerRunTime: " + date4);
//								logger.info("USETIME rc update " + (rcUpdateTime - rcSendTime));// 不能使用date1.getTime() - rcSendTime。   pod中的rcWriteTime只会记录rc创建的时间。 相减为负数
////								logger.info("USETIME pod write " + (date2.getTime() - rcUpdateTime)); 
////								logger.info("USETIME binding write " + (date3.getTime() - date2.getTime()));
////								logger.info("USETIME container run " + (date4.getTime() - date3.getTime()));
//						
//								logger.info("USETIME rc update + rc in queue+ rc cal and pod write " + (date1.getTime() - rcUpdateTime));
//								logger.info("USETIME pod in queue " + (date2.getTime() - date1.getTime()));
//								logger.info("USETIME calculate schedule " + (date3.getTime() - date2.getTime()));
//								logger.info("USETIME binding write " + (date5.getTime() - date4.getTime()));
//								logger.info("USETIME container run " + (date6.getTime() - date5.getTime()));
//									
//							}
//						} catch (ParseException e) { 
//							logger.error("convert time error", e);
//							return false;
//						}
//					}
//					return true;
//				}
//			}
//			try {
//				Thread.sleep(QUERY_INTERVAL);  
//			} catch (InterruptedException e) { 
//				logger.error(e); 
//				return false;
//			}
//			wait_time += QUERY_INTERVAL;
//		}
//		logger.error(QUERY_TIMEOUT + "used, create rc timeout!"); //超时时间内未退出，算超时
		return false;
	}
}
