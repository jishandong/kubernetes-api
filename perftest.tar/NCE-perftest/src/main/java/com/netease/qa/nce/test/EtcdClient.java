
package com.netease.qa.nce.test;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.log4j.Logger;
import org.apache.http.Header;



import com.netease.qa.nce.util.SimpleHttpClient;
import com.netease.qa.nce.util.Template;
import com.netease.qa.nce.util.UrlTools;

public class EtcdClient {

	private String baseUrl = "http://115.236.124.215:2379/v2/keys";
	private SimpleHttpClient simpleHttpClient;
	private static Logger logger = Logger.getLogger(EtcdClient.class);
	private Header[] headers;

	
	public EtcdClient() {
		this.simpleHttpClient = new SimpleHttpClient();
	}

	public void setDefaultHeaders(Header[] headers) {
		this.headers = headers;
	}
	
	public static void main(String []args){
		Header[] headers = new Header[] {
				new BasicHeader("Connection", "keep-alive"),
		};
		String key = "test3";
		String resourceType = "replicationcontrollers";
		String resourceName = "zwj-test10";
		String namespace = "default";
		EtcdClient c = new EtcdClient();
		c.setDefaultHeaders(headers);
		boolean putResult = c.putKey(key, resourceType, resourceName, namespace);
		boolean updResult = c.updateKey(key, resourceType, "wyz-test", namespace);
		boolean delResult = c.deleteKey(key);
		boolean getResult = c.getKey(key);
		logger.info(putResult);
		logger.info(updResult);
		logger.info(delResult);
		logger.info(getResult);
	}
	
	
	public boolean putKey(String key, String resourceType, String resourceName, String namespace) {  
		UrlTools urlTools = new UrlTools(baseUrl);
		String pathResourceType = resourceType;
		if(resourceType.equals("replicationcontrollers")){
			pathResourceType = "controllers";
		}
//		urlTools.addPath(key).addPath("registry").addPath(pathResourceType).addPath(namespace).addPath(resourceName);
		urlTools.addPath(key);
		List<NameValuePair> params = new ArrayList<NameValuePair>();  
		UrlEncodedFormEntity entity;
		try {
			String body = Template.get(resourceType).toString().replaceAll("default-resource-name", resourceName);
			if(resourceType.equals("replicationcontrollers")){
				//rc 要保证rc和模板中的pod的lable一致，才能根据lable查询由他创建的pod。
				//rc自己metadata.labels无所谓    因为没人会去管理 他
				body = body.replaceAll("default-resource-label-name", resourceName); 
				body = body.replaceAll("\"default-replicas\"", "1");
				logger.info(body);
			}
	        params.add(new BasicNameValuePair("value", body));  
	        entity = new UrlEncodedFormEntity(params, "utf-8"); 
		} catch (UnsupportedEncodingException e) {
			logger.error(e);
			return false;
		}
		String [] result = simpleHttpClient.put(urlTools.getCompleteUrl(), null, entity);
		if(result == null){
			return false;
		}
		if(!result[0].equals("201") && !result[0].equals("200")){
			logger.error("ERROR, code=" + result[0] + "\n"+ result[1]);
			return false;
		}
		return true;
	}
	
//	public boolean getKey(String key, String resourceType, String resourceName, String namespace) {
	public boolean getKey(String key) {
		UrlTools urlTools = new UrlTools(baseUrl);
//		String pathResourceType = resourceType;
//		if(resourceType.equals("replicationcontrollers")){
//			pathResourceType = "controllers";
//		}
//		urlTools.addPath(key).addPath("registry").addPath(pathResourceType).addPath(namespace).addPath(resourceName);
		urlTools.addPath(key);
		String[] result = simpleHttpClient.get(urlTools.getCompleteUrl(), headers);
		if(null == result)
			return false;
		if(!result[0].equals("200")) {
			logger.error("ERROR, code=" + result[0] + "\n" + result[1]);
			return false;
		}
		return true;
	}
	
	public boolean updateKey(String key, String resourceType, String resourceName, String namespace) {
		UrlTools urlTools = new UrlTools(baseUrl);
		String pathResourceType = resourceType;
		if(resourceType.equals("replicationcontrollers")) {
			pathResourceType = "controllers";
		}
//		urlTools.addPath(key).addPath("registry").addPath(pathResourceType).addPath(namespace).addPath(resourceName);
		urlTools.addPath(key);
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		UrlEncodedFormEntity entity;
		try {
			String body = Template.get(resourceType).toString().replaceAll("default-resource-name", resourceName);
			if(resourceType.equals("replicationcontrollers")) {
				//rc 要保证rc和模板中的pod的lable一致，才能根据lable查询由他创建的pod。
				//rc自己metadata。labels无所谓 因为没人会去管理 他
				body = body.replaceAll("default-resource-label-name", resourceName);
				body = body.replaceAll("\"default-replicas\"", "1");
				logger.info(body);
			}
			params.add(new BasicNameValuePair("value", body));
			entity = new UrlEncodedFormEntity(params, "utf-8");
		} catch(UnsupportedEncodingException e) {
			logger.error(e);
			return false;
		}
		String[] result = simpleHttpClient.put(urlTools.getCompleteUrl(), null, entity);
		if(null == result)
			return false;
		if(!result[0].equals("201") && !result[0].equals("200")) {
			logger.error("ERROR, code=" + result[0] + "\n" + result[1]);
			return false;
		}
		return true;
	}
	
//	public boolean deleteKey(String key, String resourceType, String resourceName, String namespace) {
	public boolean deleteKey(String key) {
		UrlTools urlTools = new UrlTools(baseUrl);
//		String pathResourceType = resourceType;
//		if(resourceType.equals("replicationcontrollers")){
//			pathResourceType = "controllers";
//		}
//		urlTools.addPath(key).addPath("registry").addPath(pathResourceType).addPath(namespace).addPath(resourceName);
		urlTools.addPath(key);
		String[] result = simpleHttpClient.delete(urlTools.getCompleteUrl(), null);
		if(null == result) 
			return false;
		if(!result[0].equals("201") && !result[0].equals("200")) {
			logger.error("ERROR, code=" + result[0] + "\n" + result[1]);
			return false;
		}
		return true;
	}
	
}
